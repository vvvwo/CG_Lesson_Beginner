#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <vector>

class VectorTrans {
public:
	
	glm::vec3 vectorTrans(glm::vec3 p, glm::vec3 v, float d) {

		glm::vec3 v_norm;
		v_norm[0] = v[0] / sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
		v_norm[1] = v[1] / sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
		v_norm[2] = v[2] / sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
		p[0] = p[0] + v_norm[0] * d;
		p[1] = p[1] + v_norm[1] * d;
		p[2] = p[2] + v_norm[2] * d;
		return p;
	
	}

	bool shootJudge(glm::vec3 p1, glm::vec3 p2, float r) {

		float dis = sqrt((p1[0] - p2[0]) * (p1[0] - p2[0]) + (p1[1] - p2[1]) * (p1[1] - p2[1]) + (p1[2] - p2[2]) * (p1[2] - p2[2]));

		if (dis <= r) {

			return true;		
		
		}
		else {

			return false;
		
		
		}
	
	}


};